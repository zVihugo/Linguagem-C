/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT05_EX13
Enunciado: Faça um algoritmo para solicitar ao usuário o código alfanumérico e o preço de vários produtos, exibir o
código e o preço do produto com menor preço, calcular e exibir a média aritmética dos preços dos
produtos. O final da entrada de dados deve ser sinalizado por meio do código “0000” (dado sentinela). 

*/

//Importando bibliotecas
#include <stdio.h>
#include <locale.h>
#include <string.h>

//Cabeçalho da função main

int main(){
    
    //Declaração de variaveis
    
	setlocale(LC_ALL, "Portuguese");
	char codigo[10], codigomenor[10];
	float preco, media = 0, menor = 0, soma;
	int i=0, n = 0;
	
	//Processamento
	
	while(strcmp(codigo, "0000") != 0){
	    
	    printf("Digite o código: ");
	    scanf("%s", codigo);
	   
	    
	    if(strcmp(codigo, "0000") == 0){ //Verifica se o código é igual a "0000", se for ele termina o programa!.
	        puts("Fim!");
	    } else {
	    
	    printf("Digite o valor do produto: ")/
	    scanf("%f", &preco);
	    
	    soma += preco; //Variavel auxiliar para guardar a soma
	    
	    if(i == 0){
	        menor = preco;
	        i =1;
	    }
	    if (preco < menor){ //Verifica se o menor, é menor
	        menor = preco;
	        strcpy(codigomenor, codigo);
	    }
	    
	   n++;
	    }
     }
     
     media = soma/n;
     
     printf("A média é: %.2f \n", media);
     printf("Código do menor é: %s \n", codigomenor);
     printf("Valor do menor é: %.2f", menor);
     
}










