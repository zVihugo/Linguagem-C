// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX07

#include <stdio.h>
#include <math.h>
#include <locale.h>

int main ()
{ 
	setlocale(LC_ALL, "Portuguese"); //Accent in devc++ IDE
	
	float a, b, c, delta, raiz, x1, x2;
	
	//Data input
	
	printf("***************************Bem vindo a calcula de baskhara***************************\n");
	printf("Digite o valor de A: ");
	scanf("%f", &a);
	
	printf("Digite o Valor de B: ");
	scanf("%f", &b);
	
	printf("Digite o valor de C: ");
	scanf("%f", &c);
	
	//Processing

	delta = pow(b, 2) - 4 * a * c;
	
	if( delta < 0 ) 
	{
		printf("Não existe valores para raízes negativas");
	}
	
	else {
		raiz = sqrt(delta);
	x1 = (-b + raiz) / 2*a;
	x2 = (-b - raiz) / 2*a;
	
	//Data output 
	
	printf("Para a equação (%.1f)x^2 + (%.1f)x + (%.1f), temos:  \n", a,b,c);
	printf("O valor de delta..................................: %.1f \n", delta);
	printf("O valor da raiz de delta..........................: %.1f \n", raiz);
	printf("E o valor de suas raízes x1: %.1f e x2: %.1f.......", x1, x2);
	}
	
	return 0;
	
}