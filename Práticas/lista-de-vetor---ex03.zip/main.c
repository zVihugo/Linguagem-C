/* 

Elabore um algoritmo para obter um conjunto de 20 elementos (números inteiros positivos), identificar o
menor elemento e a sua respectiva posição no conjunto.
Casos de teste:
a) Para o conjunto 10, 15, 5, 7, 1, 45, 100, 25, 22, 17, 95, 35, 76, 81, 11, 4, 64, 20, 32 e 8, o menor elemento
é o 1 na posição 5;
b) Para o conjunto 25, 12, 51, 17, 11, 40, 10, 28, 85, 90, 80, 13, 15, 44, 19, 5, 70, 49, 30 e 77, o menor
elemento é o 5 na posição 16;
c) Para o conjunto 12, 10, 9, 70, 29, 4, 18, 27, 44, 9, 81, 75, 62, 74, 32, 15, 6, 30, 20 e 89, o menor elemento
é o 4 na posição 6.

*/

#include <stdio.h>
#include <locale.h>
#define tam 20

int main()
{
	
	int vetor[tam], posi, i, menor;
	
	setlocale(LC_ALL, "Portuguese");
	
	printf("Vetor [0]: ")
	;
	scanf("%d", &vetor[0]);
	
	menor = vetor[0];
	posi = 0;
	
	for( i=1; i<tam; i++)
	{
		printf("Vetor [%d]: ", i);
		scanf("%d", &vetor[i]);
		
		if(vetor[i] < menor)
		{
			menor = vetor[i];
			posi = i;
		}   	
	}
	
	for(i = 0; i <tam; i++)
	{
		printf("| %d | ", vetor[i]);
			
	}
	
	printf("\n Para este vetor, o menor numero registrado é: %d e sua posição é: %d", menor, posi);
}