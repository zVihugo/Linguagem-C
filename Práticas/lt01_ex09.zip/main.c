// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX09

#include <stdio.h>
#include <locale.h>

int main(){

 setlocale(LC_ALL, "Portuguese");


 int tempo, vm, litroscheio, litros_usados, distancia; //Variable declaration
 
 //Data input
 
 printf("Digite a duração da sua viagem em horas: \n");
 scanf("%d", &tempo);
 
 printf("Digite sua velocidade na viagem: \n");
 scanf("%d", &vm);
 
 //Processing 

 litroscheio = 12 * 5;  //Faz o cálculo da distância total para acabar a gasolina 
 
 distancia = tempo * vm; //Faz o cálculo da distância total percorrida
 
 litros_usados = distancia / litroscheio; //Conversion Calculation
 
 //Data output
 
 printf("Para uma viagem de %d horas na velocidade  de %d Km/h, são necessários %d galões cheios;", tempo, vm, litros_usados);
 
 
 
 
 
 
}