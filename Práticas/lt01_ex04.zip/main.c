//// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX04

#include <stdio.h>
#include <math.h>
#include <locale.h>

int main ()
{
	setlocale(LC_ALL, "Portuguese"); //Accent in devc++ IDE
	
	int segundos, h, m, s, resto; //Variable declaration
	
	//Data input
	
	printf("Digite a duração do evento em segundos: ");
	scanf("%d", &segundos);
	
	//Processing
	
	h = segundos / 3600;
	resto = segundos % 3600; //Take the remainder of the division to proceed with the calculation
	m = resto / 60; //Calculate the minutes 
	s = resto % 60; //Calculate the seconds
	
	//Data output
	
	printf("%d Horas : %d Minutos : %d Segundos\n", h, m, s);
	return 0;
}