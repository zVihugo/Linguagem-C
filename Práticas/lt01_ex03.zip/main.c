//// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX03

#include <stdio.h>
#include <math.h>
#include <locale.h>

int main ()
{
	setlocale (LC_ALL, "Portuguese"); //Accent in devc++ IDE
	
	//Variable declaration
	
	
	float n1, n2, n3, mediaponde; 
	
	//Data input 
	
	printf("Digite o valor da primeira nota: ");
	scanf("%f", &n1);
	
	printf("Digite o valor da segunda nota: ");
	scanf("%f", &n2);
	
	printf("Digite o valor da terceira nota: ");
	scanf("%f", &n3);
	
	//Processing
	
	mediaponde = ((n1*2) + (n2*3) + (n3*5)) / (2+3+5); //Calculate the average
	
	//Data output
	
	printf("A média ponderada entre as notas informadas é: %.2f! \n", mediaponde);
	
	return 0;
	
	
}