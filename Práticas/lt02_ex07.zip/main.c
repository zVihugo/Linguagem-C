/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:21/09/2022
EX: LT02_EX07
Enunciado: Faça um algoritmo para obter dois números inteiros diferentes e exibir os números em ordem crescente
(do menor para o maior).
Casos de teste:
a) Para os números 9 e 5, serão apresentados os números 5 e 9 (nessa ordem);
b) Para os números 10 e 20, serão apresentados os números 10 e 20 (nessa ordem). 

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1, num2;
    
    printf("Bom dia!, insira somente valores inteiros.\n");
    
    printf("Digite o primeiro número: \n");
    scanf("%d", &num1);
    
    printf("Digite o segundo número: \n");
    scanf("%d", &num2);
    
    if ( num1 > num2 )
    {
        printf("A ordem crescente dos números digitados é %d e %d. \n", num2, num1);
        
    }
    else
    {
        printf("A ordem crescente dos números digitados é %d e %d", num1, num2);   
    }
}
