/*
Elabore um algoritmo para obter um conjunto de 20 elementos (números inteiros positivos), identificar o
maior elemento e a sua respectiva posição no conjunto.
Casos de teste:
a) Para o conjunto 10, 15, 5, 7, 1, 45, 100, 25, 22, 17, 95, 35, 76, 81, 11, 4, 64, 20, 32 e 8, o maior elemento
é o 100 na posição 7;
b) Para o conjunto 25, 12, 51, 17, 11, 40, 10, 28, 85, 90, 80, 13, 15, 44, 19, 5, 70, 49, 30 e 77, o maior
elemento é o 90 na posição 10;
c) Para o conjunto 12, 10, 9, 70, 29, 4, 18, 27, 44, 9, 81, 75, 62, 74, 32, 15, 6, 30, 20 e 89, o maior elemento
é o 89 na posição 20. 

*/
#include <stdio.h>
#define tam 20
#include <locale.h>

int main()
{	
	setlocale(LC_ALL, "Portuguese");
	
	int num,
		vetor[tam],
		maior,
		posi;
		
	for(num = 1; num <= tam; num++)
	{
		printf("Vetor [%d]: ", num);
		scanf("%d", &vetor[num]);
		
		if(vetor[num]>maior){
			maior = vetor[num];
			posi =  num;
		}
	}
	
	for(num = 0; num<tam; num++)
	{
		printf("|%d| ", vetor[num]);	
	}
	
	printf("\n Para este vetor, o maior numero é %d e sua posição é %d", maior, posi);
	
}
