// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX06

#include <stdio.h>
#include <math.h>
#include <locale.h>

int main ()
{ 
	setlocale(LC_ALL, "Portuguese"); //Accent in devc++ IDE
	
	//Variable declaration
	
	int km, conversao;
	
	//Data input
	
	printf("Digite a velocidade desejada para ser convertida (Km/H): ");
	scanf("%d", &km);
	
	//Processing
	
	conversao = km / 3.6; //Conversion calculation
	
	//Data output
	
	printf("A velocidade de %d Km/h corresponde á velocidade de %d m/s", km ,conversao);
	
	return 0;
}