/*
Elabore um algoritmo para calcular a matriz transposta de uma matriz n x m.
Observação: a matriz transposta é a matriz que se obtém da troca de linhas por colunas de uma dada
matriz.
*/

#include <stdio.h>
#include <locale.h>

int main(){
	
	setlocale(LC_ALL, "Portuguese");
		
	int i, j, linha, coluna;
	
	printf("Digite o tamanho da linha: \n");
	scanf("%d", &linha);
	
	printf("Digite o tamanho da coluna: \n");
	scanf("%d", &coluna);
	
	int Matriz[linha][coluna], MatrizTrans[coluna][linha];
	
	//Processamento para pegar os valores da matriz original
	
	for(i = 0; i < linha; i++){
		for(j = 0; j < coluna; j++){
			printf("[ %d ] [ %d ]: ", i + 1, j + 1);
			scanf("%d", &Matriz[i][j]);
		}
	}
	
	puts("\n");
	
	//Visualizar a matriz original
	
	puts("Matriz original\n");
	
	for(i = 0; i < linha; i++){
		for(j = 0; j < coluna; j++){
			printf("| %d |", Matriz[i][j]);
		}
		puts("\n");
	}
	
	//Realizar a transposição da matriz
	
	for(i = 0; i < linha; i++){
		for(j = 0; j < coluna; j++){
			MatrizTrans[j][i] = Matriz[i][j];
		}
	}
	
	puts("Aqui está sua matriz transposta: \n");
	
	//Exibe a matriz transposta
	
	for(i = 0; i < coluna; i++){
		for(j = 0; j < linha; j++){
			printf("| %d |", MatrizTrans[i][j]);
		}
		puts("\n");
	}
	
	
	
	return 0;
}