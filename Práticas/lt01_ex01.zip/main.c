//// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX01


#include <stdio.h>
#include <math.h>

int main ()
{
	int a,b, diferenca; //Declaração de variavel
	//Entrada

	printf("Digite o valor de a: ");
	scanf("%d", &a); //Emtrada do valor A
	
	printf("Digite o valor de b: ");
	scanf("%d", &b); //Entrada do valor B
		
	//Processamento
	
	diferenca = pow(( a+b),2); //Calculo da formula
 
	//Saída de dados
	
	printf("O resultado e: %d!", diferenca); //Mostra o resultado para o usuario
	
	
} 
