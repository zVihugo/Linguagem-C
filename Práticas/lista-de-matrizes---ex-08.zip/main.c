#include <stdio.h>
#include <locale.h>

int main(void){
	
	setlocale(LC_ALL, "Portuguese");
	
	//Definição de variaveis
	
	int l, c, linha, coluna;
	
	//O processamento abaixo pega o tamanho das linhas e colunas das matrizes
	
	printf("Digite quantos linhas a matriz possui: \n");
	scanf("%d", &linha);
	
	printf("Digite quantas colunas a matriz possui: \n");
	scanf("%d", &coluna);
	
	//Definição das matrizes
	
	int MatrizA[linha][coluna], MatrizB[linha][coluna], MatrizC[linha][coluna];
	
	//Pega os valores da matrizes A e B
	
	puts("\nDigite os valores da Matriz A: \n");
	
	for(l = 0; l < linha; l++){
		for(c = 0; c < coluna; c++){
			printf("A [ %d ][ %d ]: ", l + 1, c + 1 );
			scanf("%d", &MatrizA[l][c]);
		}
	}
	
	puts("\nDigite os valores da Matriz B: \n");
	
	for(l = 0; l < linha; l++){
		for(c = 0; c < coluna; c++){
			printf("B [ %d ][ %d ]: ", l + 1, c + 1 );
			scanf("%d", &MatrizB[l][c]);
		}
	}
	
	//Visualização das matrizes
	
	//Exibe os valors da Matriz A
	
	puts("\nMatriz A: \n");
	
	for(l = 0; l < linha; l++){
		for(c = 0; c < coluna; c++){
			printf("| %d |: ", MatrizA[l][c]);
		}
		puts("\n");
	}
	
	//Exibe os valores da Matriz B
	
	puts("\nMatriz B: \n");
	
	for(l = 0; l < linha; l++){
		for(c = 0; c < coluna; c++){
			printf("| %d |: ", MatrizB[l][c]);
		}
		puts("\n");
	}
	
	//Processamento para a criação da Matriz C
	  
	for(l = 0; l < linha; l++){
		for(c = 0; c < coluna; c++){
			MatrizC[l][c] = MatrizA[l][c] + MatrizB[l][c]; //Soma cada elemento e armazena respectiva posição da MatrizC
		}
	}
	
	//Exibe a Matriz C
	
	puts("\nMatriz C: \n");
	
	for(l = 0; l < linha; l++){
		for(c = 0; c < coluna; c++){
			printf("| %d |: ", MatrizC[l][c]);
		}
		puts("\n");
	}
	
	return 0;
	
}