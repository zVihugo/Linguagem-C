/*
Elabore um algoritmo para realizar a concatenação de dois vetores de números reais, u e v, em um terceiro
vetor, x. Como os vetores que serão concatenados podem ter qualquer número de elementos, o número
de elementos dos vetores u e v deve ser solicitado para o usuário. O tamanho do vetor x é a soma do
número de elementos de u e de v.
Observação: dimensionar o tamanho dos vetores de maneira que n sempre seja menor ou igual ao
tamanho do conjunto.
*/

#include <stdio.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL, "Portuguese"); //Como estou usando a IDE, devC++, uso este comando para acentuação
	
	int N, U[N], V[N], X[N], i, j, K, aux; //Declaração de varíaveis
	
	printf("Digite o tamanho do vetor: \n"); //Verifica qual vai ser o tamanho do vetor
	scanf("%d", &N);
	
	aux = N+N; //Guarda a soma do valor do vetor
	
	puts("Digite os valores do vetor U: \n"); 
	
	for( i = 0; i < N; i++ ) // Pega os valores do vetor U
	{
		printf("U[%d]: ", i);
		scanf("%d", &U[i]);
	}
	
	puts("\nDigite os valores de vetor V:");
	
	for( i = 0; i < N; i++ ) //Pega os valores do vetor V
	{
		printf("V[%d]: ", i);
		scanf("%d", &V[i]);
	}
	
	for(i = 0; i<N; i++) //Laço for, para pegar os valores do Verto U e alocar nos primeiros espaços do vetor X
	{
		X[i] = U[i];	
	}
	
	for(j = 0; j < N; j++) //Laço for, para pegar os valores do Vetor J e alocar nos espaços + N do vetor X
	{
		X[j+N] = V[j];
	}
	
	puts("O resultado da concatenação entre os vetores U e V é: \n");
	
	for(K=0; K < aux; K++) //Laço for para mostrar a concatenação
	{
		printf("|%d| ", X[K]);	
	}
	
	return 0;
}