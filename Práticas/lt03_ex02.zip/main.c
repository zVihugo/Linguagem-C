/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:25/09/2022
EX: LT03_EX02
Enunciado: Elabore um algoritmo para ler um número inteiro de 1 a 7 e informar o dia da semana correspondente,
sendo domingo o dia de número 1. Se o número não corresponder a um dia da semana, mostrar uma
mensagem de erro.
Casos de teste:
a) Para o número do dia da semana igual a 1, será apresentada a mensagem “Domingo”;
b) Para o número do dia da semana igual a 6, será apresentada a mensagem “Sexta-feira”;
c) Para o número do dia da semana igual a 9, será apresentada a mensagem “O número informado não
corresponde a um dia da semana”. 



*******************************************************************************/
#include <stdio.h>

//Cabeçalho da função main
int main()
{
    //Declaração de variavel 
    int num;
    //Entrada de dados
    printf("Bom dia, tudo bem?\n");
    printf("Digite um número inteiro de 1 a 7: \n");
    scanf("%d", &num);
    
    //Processamento
    switch(num){
        case 1:
            printf("Domingo"); //Saída de dados para 1
            break;

        case 2:
            printf("Segunda-Feira"); //Saída de dados para 2
            break;
    
        case 3:
            printf("Terça-Feira"); //Saída de dados para 3
            break;

        case 4:
            printf("Quarta-Feira"); //Saída de dados para 4
            break;
    
        case 5:
            printf("Quinta-Feira"); //Saída de dados para 5
            break;
    
        case 6:
            printf("Sexta-Feira"); //Saída de dados para 6
            break;
   
        case 7:
            printf("Sábado"); //Saída de dados para 7
            break;
    
        default:
            printf("O número informado não corresponde a um dia da semana."); //Saída de dados para um valor, que não estja no intervalo (1-7)
            break;

    }
    return 0;
}

