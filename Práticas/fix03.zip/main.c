// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data: 01/09/2022
// Enunciado: FIX03_EX03

#include <stdio.h>

int main ()
{
	float Celsiu, far;

	printf("Digite uma temperatura em graus celsius: ");
	scanf("%f", &Celsiu);

	far = (9 * Celsiu / 5) + 32;

	printf("A sua temperatura convertidada em fahrenheit e: %.1f!", far);
}
