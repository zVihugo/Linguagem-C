/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:22/09/2022
EX: LT02_EX08
Enunciado: Faça um algoritmo para obter três números inteiros diferentes e exibir os números em ordem crescente
(do menor para o maior).
Casos de teste:
a) Para os números 9, 7 e 5, serão apresentados os números 5, 7 e 9 (nessa ordem);
b) Para os números 10, 20 e 30, serão apresentados os números 10, 20 e 30 (nessa ordem);
c) Para os números 2, 4 e 3, serão apresentados os números 2, 3 e 4 (nessa ordem);
b) Para os números 30, 25 e 35, serão apresentados os números 25, 30 e 35 (nessa ordem);
b) Para os números 22, 23 e 21, serão apresentados os números 21, 22 e 23 (nessa ordem);
b) Para os números 125, 55 e 100, serão apresentados os números 55, 100 e 125 (nessa ordem). 


*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1, num2, num3, maior, menor, medio;
    
    //Entrada de dados
    
    printf("Digite o valor do primeiro numero: \n");
    scanf("%d", &num1);
    
    printf("Digite o valor do segundo numero: \n");
    scanf("%d", &num2);
    
    printf("Digite o valor do terceiro numero: \n");
    scanf("%d", &num3);
    
    //Processamento
    
    if (num1 > num2 && num1 > num2)
    {
        maior = num1;
        if ( num2 > num3){
            medio = num2;
            menor = num3;
        }
        else {
            medio = num3;
            menor = num2;
        }
    } else if (num2 > num3 && num2 > num3){
        maior = num2;
        if (num3 > num1){
            medio = num1;
            menor = num3;
        
        }
        else {
            medio = num3;
            menor = num1;
            
        }
    } else {
        if ( num2 > num1){
            medio = num2;
            menor = num1;
    }   else{
        medio = num1;
        menor = num2;
    }

}
    //Saída de dados
    
    printf("Para os números %d, %d e %d, serão apresentados os números %d, %d e %d", num1, num2, num3, menor, medio, maior);
    return 0;
}

