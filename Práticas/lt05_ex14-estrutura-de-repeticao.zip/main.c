#include <stdio.h>
#include <string.h>

//Cabeçalho da função main
int main(){
	
	//Declaração de variavéis
	
	int quantidade, auxquanti =0, mercadoria = 0;
	float preco, valor_total = 0, media = 0, aux = 0;
	char sn;
	
	//Processamento
	
	do { 
	    
	    //Entrada de dados
	    printf("Digite a quantidade do produto: \n");
	    scanf("%d", &quantidade);
	
	    printf("Digite o valor do produto: \n");
	    scanf("%f", &preco);
	
	    //Processamento de cálculos
	    
	    aux += preco;
	    
	    auxquanti =  preco * quantidade;
	    
	    valor_total = valor_total + auxquanti;
	    
	    printf("Deseja inserir mais produtos? \n");
	    scanf(" %c", &sn);
	    
	    mercadoria++;
	    
	} while(sn == 'S' || sn == 's'); //Enquanto a variavel sn, for igual a 'S' ou 's', ele repete o processamento acima
		
	media = aux / mercadoria;
    
    //Saída de dados
    
	printf(" Valor total em estoque: R$ %.2f ", valor_total);
	printf(" Media dos produtos: %.2f", media);
	
	
}


