/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:07/09/2022
EX: LT02_EX04
Enunciado: Elabore um algoritmo para obter dois números do usuário e identificar o maior e o menor ou se são iguais.
Observação: a saída deve ser formatada.
Casos de teste:
a) Para os números 5 e 8, a saída deve ser a seguinte:
Maior: 8
Menor: 5
b) Para os números 9 e 1, a saída deve ser a seguinte:
Maior: 9
Menor: 1
c) Para os números 3 e 3, a saída deve ser a seguinte:
Iguais: 3

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1, num2;
    
    printf("Digite o primeiro valor: ");
    scanf("%d", &num1);
    
    printf("Digite o primeiro valor: ");
    scanf("%d", &num2);
    
    if (num1 > num2 )
    {
        printf("Maior: %d\n", num1);
        printf("Menor: %d\n", num2);
    }
    else if (num1==num2)
    {
        printf("Iguais: %d", num1);
    }
    else 
    {
     printf("Maior: %d\n", num2);
     printf("Menor: %d\n", num1);
     
    }
    return 0;
}

