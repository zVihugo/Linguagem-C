/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT05_EX15
Enunciado: A prefeitura de uma cidade deseja fazer uma pesquisa sobre a sua população economicamente ativa. Faça
um algoritmo para coletar dados sobre salário e número de filhos de cada habitante e apresentar ao final
da entrada dos dados:
a) Média do salário dos habitantes;
b) Média do número de filhos;
c) Maior salário dos habitantes;
d) Quantidade com salário menor que R$ 3.300,00. 

*/

//Bibliotecas
#include <stdio.h>
#include <locale.h>

//Cabeçalho da função main

int main()
{
    //Declaração de variaveis
    
    char sn;
    int filhos, quantfilhos = 0, auxsal = 0, auxfilhos = 0, cont = 0;
    float mediafilho = 0, mediasal, quantsal, sal, maiorsal = 0;
    
    setlocale(LC_ALL, "Portuguese");
    
    //Saída de dados, com mensagem bonitinha para o usuário
    
    puts("Bom dia, tudo bem?\n");
    
    //Processamento
    
    do {
        
        printf("Digite o valor do seu sálario atual: \n");
        scanf("%f", &sal);
        
        auxsal = auxsal + sal; // auxsal += sal;
        
        if(sal < 3300){ // Verifica se o salário é menor que R$ 3.300,00
            cont++;
        }
                
        printf("Quantos filhos você tem? \n");
        scanf("%d", &filhos);
        
        auxfilhos = auxfilhos + filhos; // auxfilhos += filhos;
        
        if(sal > maiorsal){ //Verifica qual é o maior salário inserido
            
            maiorsal = sal;
            
        }
        
        //Contadores
        
        quantsal ++; 
        quantfilhos++;
        
        printf("Deseja inserir mais dados? (Responda com S ou N) \n");
        scanf(" %c", &sn);
        
    } while(sn == 'S' || sn == 's');
    
    //Realiza o cálculo das médias
    
    mediafilho =  auxfilhos / quantfilhos;
    mediasal = auxsal / quantsal;
    
    //Saída de dados
    
    printf("A média de filhos é: %.1f \n", mediafilho);
    printf("A média de salários é: R$ %.2f \n", mediasal);
    printf("O maior salário é: %.2f \n", maiorsal);
    printf("Quantidade de salários menores que R$ 3.300,00 é: %d", cont);
     
    return 0;
}


