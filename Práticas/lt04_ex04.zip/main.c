/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX04
Enunciado: Elabore um algoritmo para solicitar ao usuário um número inteiro e apresentar a sua tabuada.
Casos de teste:
Elabore um algoritmo para mostrar todos os números a partir do zero até um número positivo fornecido
pelo usuário. 
*/
#include <stdio.h>

int main(){
	
	//Declaração de variaveis
	int num, x = 1;
	//Entrada de dados
	scanf("%d", &num);
	//Processamento
		while(x <= num){
		//Saída de dados
		printf("%d ", x);
		x+=2;
		}
	
	return 0;
}


