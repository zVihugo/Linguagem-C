//// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX02

#include <stdio.h>
#include <math.h>
#include <locale.h>

int main () //Starting place
{
	setlocale(LC_ALL, "Portuguese"); //Accent in devc++ IDE
	//variable declaration
	
	int a, x2, x3; 

	//Data input
	
	printf("Digite um valor inteiro: \n");
	scanf("%d", &a); //Assigns the value to the variable a
	
	//Processing
	
	x2 = pow(a, 2); //Pow function as exponent of 2
	x3 = pow(a, 3);//Pow function as exponent of 3
	
	//Data output
	
	printf("O número informado elevado ao quadrado é: %d\n", x2);
	printf("O número informado elevado ao cubo é....: %d\n", x3);
	
	return 0;
	
}