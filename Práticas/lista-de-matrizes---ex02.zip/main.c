/*
Elabore um algoritmo para calcular a soma de todos os elementos de uma matriz 2 x 3 (duas linhas e três
colunas).
Caso de teste:
A = ?
12 28 4
0 10 14?
Para a matriz A, a soma de todos os elementos é 68. 
*/

#include <stdio.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL, "Portuguese");
	
	int i=0, j=0, mat[2][3], a=0; 
	
	//Entrada de dados
	
	for( i =0; i < 2; i++){
		for(j = 0; j<3; j++){
			printf("Linha %d, coluna %d: ", i+1, j+1);
			scanf("%d", &mat[i][j]);
			a += mat[i][j]; 
		}
	} 
	
	printf("A soma é: %d", a);
	
}