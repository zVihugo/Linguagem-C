/******************************************************************************
Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:07/09/2022
EX: LT02_EX02
Enunciado: Elabore um algoritmo para identificar se um número inteiro fornecido pelo usuário é zero, positivo ou
negativo.
Casos de teste:
a) Para o número 5, será apresentada a mensagem “Positivo”;
b) Para o número -5, será apresentada a mensagem “Negativo”;
c) Para o número 0 (zero), será apresentada a mensagem “Zero”. 

*******************************************************************************/
#include <stdio.h>

int main ()
{
    int num;
    
    //Entrada de dados
    
    printf("Digite um número: \n");
    scanf("%d", &num);
    
    //Processamento
    if (num>0){
        
        //Saída de dados
        
        printf("Positivo.");
    }
    else if (num == 0) {
        
         //Saída de dados
        
        printf("Zero");
    }
    else {
        printf("Negativo");
    }
    return 0;
}