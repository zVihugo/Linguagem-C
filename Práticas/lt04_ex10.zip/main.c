/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX10
Enunciado:  Faça um algoritmo para solicitar 10 valores positivos para o usuário e, ao final, exibir o maior e o menor
desses valores.
Casos de teste:
a) Para os números 10, 5, 50, 100, 75, 30, 80, 1, 45 e 20, o maior é 100 e o menor é 1;
b) Para os números 150, 200, 33, 55, 20, 51, 65, 90, 20 e 100, o maior é 200 e o menor é 20;
c) Para os números 80, 0, 100, 55, 60, 89, 90, 85, 59 e 110, o maior é 110 e o menor é 0.  
*/
#include <stdio.h>
//Cabeçalho
int main()
{
	//Declaração de variveis
   int num=0,
       aux=0,
       contador=1,
       maior=0,
       menor=99999;
       //Processamento
       while(contador<=10){
       	scanf("%d", &num);
       		if(num<menor){ //Verifica se o numero digitado é menor que o menor já armazenado
       			menor = num;
			   }
			else if(num>maior){ //Verifica se o numero digitado é maior que o maior ja digitado
				maior = num;
			}
       	contador++; //Conta as repetições
	   }//Saída de dados
	   printf("O menor é %d, e o maior é %d", menor, maior);
}

