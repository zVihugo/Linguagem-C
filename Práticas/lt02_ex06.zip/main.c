/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:21/09/2022
EX: LT02_EX06
Enunciado: Faça um algoritmo para o usuário entrar com dois números e exibir a saída de acordo com as seguintes
condições:
 Caso a soma dos dois números seja um número par maior que 100, exibir a metade da soma dos dois
números;
 Caso a soma dos dois números seja um número par menor que 100, exibir a soma multiplicada por
dois;
 Caso a soma dos dois números resultar em um número ímpar, exibir apenas a soma.
Casos de teste:
a) Para os números 55 e 63, será apresentado o número 59118;
b) Para os números 31 e 13, será apresentado o número 88;
c) Para os números 55 e 70, será apresentado o número 125;
d) Para os números 27 e 10, será apresentado o número 37
*******************************************************************************/
#include <stdio.h>

int main()
{
   int num1, num2, soma, aux;
   float divi;
   
   //Entrada de dados
   
   printf("Bom dia!, insira somente números inteiros.\n");
   
   printf("Digite o primeiro número: \n");
   scanf("%d", &num1);
   
   printf("Digite o segundo número: \n");
   scanf("%d", &num2);
   
   soma = num1+num2;
   
   if ( soma%2==0 && soma>100) 
   {
        divi = soma/2;
        
        printf("%.0f", divi);
        
   }
   if ( (soma%2==0) && (soma<100) )
   {
        aux = soma * 2;
        
        printf("%d", aux);
   }
   
   else 
   {
       printf("%d", soma);
   }
       
    return 0;
}
