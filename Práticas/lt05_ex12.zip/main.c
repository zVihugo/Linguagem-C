/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT05_EX12
Enunciado:  Elabore um algoritmo para ler o nome e o sexo de 10 pessoas, mostrar o nome da pessoa precedido de
Sr. ou Sra. (de acordo com o sexo) e apresentar no final a quantidade de pessoas do sexo masculino e a
quantidade de pessoas do sexo feminino. 
Caso de teste: 

*/
#include <stdio.h>
#include <string.h>

int main()
{
    char nome[15], sexo;
    int contm=0, contf=0, i, n = 2;
    
    for (i=1; i<=n; i++){
        printf("Digite o nome da pessoa: \n");
        scanf("%s", nome);
        
        printf("Digite o sexo da pessoal, escolha entre M ou F: \n");
        scanf(" %c", &sexo);
        
        switch (sexo){
            case 'M':
                printf("Sr. ");
                contm++;
                break;
            
            case 'F':
                printf("Sra. ");
                contf++;
                break;
        }
        printf("%s \n", nome);
    }
    printf("A quantidade de homens é: %d \n",contm);
    printf("A quantidade de mulheres são: %d",contf);
}



