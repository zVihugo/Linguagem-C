/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:23/09/2022
EX: LT02_EX12
Enunciado: Elabore um algoritmo que solicite ao usuário o nome e a idade de uma criança e, de acordo com a idade,
informar qual a sala de aula da criança.
Idade Sala
0 a 2 anos Sala 1
3 a 5 anos Sala 2
6 a 8 anos Sala 3
9 a 10 anos Sala 4
Casos de teste:
a) Para uma criança de 1 ano, a sala de aula é a “Sala 1”;
b) Para uma criança de 3 anos, a sala de aula é a “Sala 2”;
c) Para uma criança de 8 anos, a sala de aula é a “Sala 3”;
d) Para uma criança de 10 anos, a sala de aula é a “Sala 4”. 


*******************************************************************************/
#include <stdio.h>

int main()
{
    
    //Variable declaration 
    
    int idade;
    char nome[20];
    
    //Data input 
    
    printf("Digite o nome da criança: \n");
    fgets(nome, 20, stdin);
    
    printf("Digite a idade da criança? \n");
    scanf("%d", &idade);
    
    
    //Processing and data output 
    
    if (idade < 3){ 
        printf("Para uma criança de %d, a sala de aula é a ""Sala 1"" ", idade);
    }
    
    if (idade >= 3 && idade <=5){
       printf("Para uma criança de %d, a sala de aula é a ""Sala 2"" ", idade);
    }
    if (idade > 5 && idade <= 8){
        printf("Para uma criança de %d, a sala de aula é a ""Sala 3"" ", idade);
    }
    if (idade > 8 && idade <= 10){
        printf("Para uma criança de %d, a sala de aula é a ""Sala 4"" ", idade);
    }
    else {
        printf("Não temos salas de aulas disponiveis para essa faixa etária. ");
    }
    
    return 0;
}










