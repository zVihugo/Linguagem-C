/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:21/09/2022
EX: LT02_EX05
Enunciado: Faça um algoritmo para obter um valor qualquer e depois perguntar ao usuário se este valor está em
dólares ou em reais e fazer o seguinte:
 Caso a escolha do usuário for dólares, converter o valor para reais;
 Caso a escolha do usuário for reais, converter o valor para dólares.
Observação: O algoritmo deve solicitar ao usuário a cotação atual do dólar.
Casos de teste:
a) Para o valor de 100 em dólares, com a cotação do dólar em 5,20 reais, o valor em reais é 520 reais;
b) Para o valor de 100 em reais, com a cotação do dólar em 5,20 reais, o valor em dólar é 19,23 dólares. 

*******************************************************************************/
#include <stdio.h>

int main()
{
    float vqualquer, cotacao, conversao;
    int escolha; 
    
    //Entrada de dados
    
    printf("Digite um valor qualquer: \n");
    scanf("%f", &vqualquer);
    
    printf("Caso o valor esteja em dólar digite 1, caso esteja em Reais digite 2: \n"); //Pede para o usuário escolher a moeda
    scanf("%d", &escolha);
    
    printf("Digite o valor da cotação atual: \n");
    scanf("%f", &cotacao);
    
    //Processamento
    
    if (escolha == 1)
    {
        
        conversao = vqualquer * cotacao; //Converte para real - dólar
        
        printf("Para o valor de %.1f em dólares, com a cotação do dólar em %.2f, o valor em reias é %.2f reais.", vqualquer, cotacao, conversao); //Saída de dados
        
    }

    else 
    {
     
        conversao = vqualquer / cotacao; //Converte dólar - Real
        
        printf("Para o valor de %.1f em reais, com a cotação do dólar em %.2f, o valor em dólar é %.2f", vqualquer, cotacao, conversao); //Saída de dados
    }
    return 0;
}

