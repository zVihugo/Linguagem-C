/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX06
Enunciado: Elabore um algoritmo para solicitar ao usuário um número inteiro e apresentar a sua tabuada.
Casos de teste:
Elabore um algoritmo para mostrar todos os números a partir do zero até um número positivo fornecido
pelo usuário. 
*/
#include <stdio.h>

int main(){
    //Declaração de Variaveis 
    int contador;
    float valor, media, somamedia;
    contador = 1;
    media = 0;
    somamedia = 0;
    //Processamento
    while(contador<=10){
        printf("Digite a nota: \n");
        scanf("%f", &valor);
        
        somamedia += valor;
        contador++;
    }
    
    media = somamedia/10;
    //Saída de dados
    printf("A média é: %.2f", media);
    
    return 0;
}