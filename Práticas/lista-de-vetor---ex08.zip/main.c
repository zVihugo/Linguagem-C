/*
Faça um algoritmo para obter dois vetores V1 e V2 de 10 números inteiros cada, calcular e apresentar a
quantidade de vezes que esses vetores possuem números iguais nas mesmas posições.
Casos de teste:
a) Para V1 = [10 5 50 15 25 30 12 1 45 20] e V2 = [5 5 50 15 20 30 12 1 10 25], a quantidade de
números iguais mesmas posições é 5;
b) Para V1 = [0 1 2 3 4 5 6 7 8 9] e V2 = [0 1 0 1 0 1 0 1 0 1], a quantidade de números iguais
mesmas posições é 2;
c) Para V1 = [10 20 30 30 20 10 20 30 40 50] e V2 = [10 20 30 20 20 30 20 30 40 50], a quantidade
de números iguais mesmas posições é 8. 
*/

#include <stdio.h>
#include <locale.h>
#define N 10

int main()
{
	setlocale(LC_ALL, "Portuguese");
	
	int V1[N], V2[N], i, cont = 0;
	
	printf("Digite os valores de V1: \n");
	
	for(i=0; i<N; i++)
	{
		printf("Vetor[%d]: ", i);
		scanf("%d", &V1[i]);
	}
	
	puts("\nDigite os valores de V2: ");	
	for(i=0; i<N; i++)
	{
		printf("Vetor[%d]: ", i);
		scanf("%d", &V2[i]);
	}
	
	for(i=0; i<N; i++)
	{
		if(V1[i] == V2[i])
		{
			cont++;
		}
	}
	
	printf("A quantidade de números iguais de mesma posição é: %d", cont);
}