/*Elaborar um algoritmo para obter uma matriz M de ordem 5 e calcular dois vetores (ambos com 5
elementos) que contenham respectivamente as somas das linhas e das colunas de M. 
*/

#include <stdio.h>
#include <locale.h>
#define T 5

int main(void){
	
	int Matriz[T][T], Vetor1[T], Vetor2[T],
		l, c, soma=0;
	
	//Pega os valores da Matriz 5x5
		
	for(l = 0; l < T; l++){
		for(c = 0; c < T; c++){
			printf("[ %d ][ %d ]: ", l + 1, c + 1);
			scanf("%d", &Matriz[l][c]);
		}
	}
	
	//Realiza o processamento para a criação do Vetor1
	
	for(l=0;l<T;l++)
	{
		soma = 0; 
		for(c=0;c<T;c++)
		{
			soma += Matriz[l][c]; 
		}
		Vetor1[l] = soma; 
	}
	
	//Realiza o processamento para a criação do Vetor2
	
	for(l=0;l<T;l++)
	{
		soma = 0; 
		for(c=0;c<T;c++)
		{
			soma += Matriz[c][l]; 
		}
		Vetor2[l] = soma; 
	}
	
	//Exibe na tela a Matriz
	
	puts("\nMatriz Principal: \n");
	for(l = 0; l < T; l++){
		for(c = 0; c < T; c++){
			printf("| %d |", Matriz[l][c]);
		}
		puts("\n");
	}
	
	//Exibe na tela o Vetor 1
	
	puts("Vetor 1: \n");
	for(l = 0; l < T; l++){
		printf(" %d  ", Vetor1[l]);
	}
	
	//Exibe na tela o Vetor 2
	
	puts("\nVetor 2: \n");
	for(c = 0; c < T; c++){
		printf(" %d  ", Vetor2[c]);
	}
	
	return 0;
}