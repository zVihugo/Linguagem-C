/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT05_EX16
Enunciado: Faça um algoritmo para calcular o resultado de uma divisão representada por uma fração. Solicitar o
numerador e o denominador para o usuário e, se o denominador for igual a zero, mostrar a mensagem
“Erro: divisão por zero” e solicitar novamente o denominador. A divisão somente será realizada quando o
usuário entrar com um denominador diferente de zero.
Casos de teste:
a) Para numerador igual a 16 e denominador igual a 2, o resultado é 8;
b) Para numerador igual a 5 e denominador igual a 0, será apresentada a mensagem “Erro: divisão por
zero” e será solicitado novamente o denominador;
c) Para numerador igual a 5 e denominador igual a 2, o resultado é 2.5. 

*/

#include <stdio.h>
#include <locale.h>

//Cabeçalho da função main

int main()
{
	
	setlocale(LC_ALL, "Portuguese");
	
	//Declaração de variaveis 
	
	float numerador, denominador, div;
	
	//Processamento
	
	printf("Digite o valor do numerador: \n");
	scanf(" %f", &numerador);
	
	do{ //Basicamente, fazer este processamento abaixo, enquanto a variavel N não respeite a condição do IF 
		printf("Digite o valor do denominador: \n");
		scanf(" %f", &denominador);
		
		if (denominador == 0 ){
			printf("Erro: divisão por zero!!!!!!!!!!!!!!! \n");
		}
	} while(denominador == 0);
	
	//Saída de dados
	
	div = numerador / denominador; // Faz a divisão
	
	printf("Para o numerador %.0f e o denominador %.0f, o resultado da divisão é: %.1f \n", numerador, denominador, div);
    return 0;
}
