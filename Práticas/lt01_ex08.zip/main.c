
#include <stdio.h>
#include <math.h>
#include <locale.h>
  
int
main () 
{
  
setlocale (LC_ALL, "Portuguese");
  
 
float despesa, receita, margeml, lucro;
  
 
    //Data input
    
printf ("OlC! comerciante, tudo bem?\n");
  
printf ("Digite o custo do produto: ");
  
scanf ("%f", &despesa);
  
 
printf ("Digite o preC'o de venda do produto: ");
  
scanf ("%f", &receita);
  
 
    //Processing
    
lucro = receita - despesa;
  
margeml = (lucro / receita) * 100;
  
 
    //Data output
    
printf
    ("A margem de lucro em porcentagem, obtida pela venda de seu produto C): %.2f",
     margeml);

 
 
}
