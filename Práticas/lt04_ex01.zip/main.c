/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX01
Enunciado: Elabore um algoritmo para solicitar ao usuário um número inteiro e apresentar a sua tabuada.
Casos de teste:
a) Para a tabuada do número 3, apresentar na saída:
Tabuada do 3
3 x 1 = 3
3 x 2 = 6
3 x 3 = 9
3 x 4 = 12
3 x 5 = 15
3 x 6 = 18
3 x 7 = 21
3 x 8 = 24
3 x 9 = 27
3 x 10 = 30 
*/
#include <stdio.h>

int main(){
	
	//Declaração de variaveis
	int num=1, cal;
	//Processamento
	printf("Tabuada do 3\n");
	while(num<=10){
		cal = num*3;
		//Saída de dados
		printf("3 x %d = %d\n", num, cal);
		num++;
	}
	return 0;
}