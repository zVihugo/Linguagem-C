/*
Faça um algoritmo para obter e apresentar uma matriz quadrada de ordem 3 cujos elementos são
números inteiros positivos.
Observação: uma matriz quadrada é um tipo especial de matriz que possui o mesmo número de linhas e
o mesmo de colunas; uma matriz n x n é conhecida como uma matriz quadrada de ordem n.
Caso de teste (exemplo de uma provável entrada e saída de dados formatada): 
*/

#include <stdio.h>
#include <locale.h>


int main()
{
	setlocale(LC_ALL, "Portuguese");
	
	int mat[3][3], i = 0, j = 0;
	
	for(i = 0; i < 3; i++){
		for(j = 0; j<3; j++){
			printf("Linha %d,  coluna %d : ", i+1, j+1);
			scanf("%d", &mat[i][j]);
		}
	}
	
	puts("A sua matriz é: \n");
	
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			printf("%d ", mat[i][j]);
		}
		printf("\n");
	}
}