/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:22/09/2022
EX: LT02_EX10
Enunciado: Elabore um algoritmo que, para uma conta bancária, solicite o seu número, o saldo, o tipo de operação a
ser realizada (1 para depósito ou 2 para retirada) e o valor da operação; depois, calcule e mostre o novo
saldo e, se o novo saldo estiver negativo, mostre a mensagem “Conta com saldo negativo”.
Casos de teste:
a) Para a conta número 123-4, saldo de R$ 1.000,00, operação 1 (depósito) e valor de operação de
R$ 500,50, será apresentado o saldo de R$ 499,50;
b) Para a conta número 300-0, saldo de R$ 500,00, operação 2 (retirada) e valor de operação de
R$ 500,50, será apresentado o saldo de -R$ 0,50 e a mensagem “Conta com saldo negativo”.
c) Para a conta número 444-5, saldo de R$ 1.500,00, operação 2 (retirada) e valor de operação de
R$ 500,00, será apresentado o saldo de R$ 1.000,00. 

*******************************************************************************/
#include <stdio.h>

int main()
{
    float saldo, valorOp, saldoAtual;
    int tip, numCont;
    
    printf("Digite o número da sua conta bancária: \n");
    scanf("%d", &numCont);
    
    printf("Digite o saldo da conta: \n");
    scanf("%f", &saldo);
    
    printf("Digite o tipo de operação desejada:  1 para depósito ou 2 para retirada: \n");
    scanf("%d", &tip);
    
    printf("Digite o valor da operação: \n");
    scanf("%f", &valorOp);
    
    if (tip == 1){
        saldoAtual = saldo + valorOp;
        
        printf("Para a conta número %d, saldo de R$ %.2f, operação %d (Depósito) e valor de operação de R$ %.2f, será apresentado o saldo de R$ %.2f", numCont, saldo, tip, valorOp, saldoAtual);
        
    }
    else if (tip==2){
        
        if (valorOp>saldo){
            saldoAtual = valorOp - saldo;
            printf("Para a conta número %d, saldo de R$ %.2f, operação %d (retirada) e valor de operação de R$ %.2f, será apresentado o saldo de -R$ %.2f, “Conta com saldo negativo”,", numCont, saldo, tip, valorOp, saldoAtual);
            
        }
        else{
            saldoAtual = valorOp - saldo;
            printf("Para a conta número %d, saldo de R$ %.2f, operação %d (Retirada) e valor de operação de $ %.2f, será apresentada o saldo de R$ %.2f", numCont, saldo, tip, valorOp, saldoAtual);
        }
    }
    
    return 0;
}


