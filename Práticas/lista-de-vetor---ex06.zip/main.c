/*
Faça um algoritmo para obter dois conjuntos (vetores) A e B (ambos de tamanho n) e calcular o conjunto
(vetor) C = A + B, sendo que cada elemento Ci = Ai + Bi, para i = 1, 2, ... , n. Apresentar no final os conjuntos
A, B e C.
Observação: dimensionar o tamanho dos vetores de maneira que n sempre seja menor ou igual ao
tamanho do conjunto.
Casos de teste:
a) Para n (tamanho) igual a 5, A = [10 9 7 4 1] e B = [1 0 6 7 2], então C = [11 9 13 11 3];
b) Para n (tamanho) igual a 3, A = [15 20 50] e B = [10 5 20], então C = [25 25 70];
c) Para n (tamanho) igual a 10, A = [0 5 10 15 20 25 30 35 40 45] e B = [5 0 5 0 5 0 5 0 5 0], então
C = [5 5 15 15 25 25 35 35 45 45]. 
*/

#include <stdio.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL, "Portuguese");
	
	int N = 0, VetorA[N], VetorB[N], VetorC[N], i; //Declaração de variaveis
	
	printf("Digite qual vai ser o tamanho do seu vetor: \n"); //Mensagem de saída para o usuário
	scanf("%d", &N); //Pega o valor do tamanho do vetor
	
	puts("Insira os valores do vetor A :\n"); //Mensagem de saída
	
	for (i = 0; i < N; i++) //Laço de repetição para pegar os valores contido dentro do vetorA
	{
		printf("Vetor[%d]: ", i);
		scanf("%d", &VetorA[i]);	
	}
	
	puts("Digite o valores do Vetor B: \n"); //Laço de repetição para pegar os valores contido dentro do vetorB
	
	for (i = 0; i < N; i++)
	{
		printf("Vetor[%d]: ", i);
		scanf("%d", &VetorB[i]);	
	}
	
	for (i = 0; i < N; i++) //Laço de repetição para somar os vetores
	{
		VetorC[i] = VetorA[i] + VetorB[i];	
	}
	
	puts("A soma de cada elemento dos vetores A e B é: \n");
	
	for (i = 0; i < N; i++) //Mensagem de saída para mostrar como foi a soma de vetores
	{
		printf("| %d | ", VetorC[i]);
	}
	
	return 0;		
}