/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX09
Enunciado: Faça um algoritmo para obter dois números inteiros positivos do usuário e calcular a soma dos números
inteiros existentes entre os dois números fornecidos (inclusive os que foram fornecidos). Considere que o
segundo número fornecido será sempre maior que o primeiro
Casos de teste:
a) Para os números 5 e 10, a soma é 45;
b) Para os números 150 e 300, a soma é 33.975;
c) Para os números 0 e 20 a soma é 210.  
*/
#include <stdio.h>

int main()
{
    int i=0, num1=0, num2=0, soma=0;
    scanf("%d", &num1);
    scanf("%d", &num2);
    i = num1;
    
    while(i<=num2){
        soma +=i;
        i++;
    }
    printf("A soma é : %d", soma);
}

