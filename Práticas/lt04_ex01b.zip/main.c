/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX01
Enunciado: Elabore um algoritmo para solicitar ao usuário um número inteiro e apresentar a sua tabuada.
Casos de teste:
b) Para a tabuada do número 10, apresentar na saída:
Tabuada do 10
10 x 1 = 10
10 x 2 = 20
10 x 3 = 30
10 x 4 = 40
10 x 5 = 50
10 x 6 = 60
10 x 7 = 70
10 x 8 = 80
10 x 9 = 90
10 x 10 = 100 
*/
#include <stdio.h>

int main(){
	
	//Declaração de variaveis
	int num=1, cal;
	//Processamento
	printf("Tabuada do 10\n");
	while(num<=10){
		cal = num*10;
		//Saída de dados
		printf("10 x %d = %d\n", num, cal);
		num++;
	}
	return 0;
}