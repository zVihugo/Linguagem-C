// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data: 01/09/2022
// Enunciado: FIX02_EX02

#include <stdio.h>
  
int
main () 
{
  
int ano, anoatual, idadeprov;
  
 
printf ("Digite o ano que voce nasceu: ");
  
scanf ("%d", &ano);
  
 
anoatual = 2022;
  
 
idadeprov = anoatual - ano;
  
 
printf ("A sua provavel idade e: %d!", idadeprov);

} 
