/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT05_EX01
Enunciado:  Elabore um algoritmo para solicitar ao usuário o código alfanumérico e o preço de 15 produtos, exibir o
código e o preço do produto com maior preço, calcular e exibir a média aritmética dos preços dos
produtos.
Caso de teste: 

*/
#include <stdio.h>
#include <locale.h>
#include <string.h>

int main(){
	setlocale(LC_ALL, "Portuguese");
	char codigo[10], codigomaior[10];
	float preco, media, maior=0;
	int i=0, n=1, soma=0;
	
	printf("Digite o quantos produtos será inserido:  \n");
	scanf("%i", &i);
	
	while(n<=i){ //Inicialização, condição, incremento
		printf("Digite o código do produto: \n");
		scanf("%s", codigo);
		printf("Digite o preço do produto: \n");
		scanf("%f", &preco);
		soma += preco; //Soma = soma+preco
		if(preco> maior){ //Compara os preços pra ver quem é o maior
			maior = preco; //Armazena o maior preço na variavel maior
			strcpy(codigomaior, codigo); //Comandoo de atribuição para variaveis 
		}	
		n++;
	}
	media = soma/i;  // Realiza a media, com o resultado da soma
	printf("Código do produto com maior preço: %s \n", codigomaior);
	printf("Produto com maior valor: R$ %.2f\n", maior);
	printf("Média dos produtos é: %.2f\n", media);
}

