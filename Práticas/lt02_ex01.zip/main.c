/******************************************************************************
Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:07/09/2022
EX: LT02_EX01
Enunciado: Elabore um algoritmo para identificar se um número inteiro fornecido pelo usuário é positivo ou negativo
(considere zero como positivo).
Casos de teste:
a) Para o número 5, será apresentada a mensagem “Positivo”;
b) Para o número -5, será apresentada a mensagem “Negativo”;
c) Para o número 0 (zero), será apresentada a mensagem “Positivo”. 
*******************************************************************************/
#include <stdio.h>

int main()
{
    int num = 0;
    
    printf("Digite um número: \n");
    scanf("%d", &num);
    
    if (num >= 0 )
    {
        printf("Positivo.\n");
    }
    else {
        printf("Negativo.");
    }
    
    return 0;
}
