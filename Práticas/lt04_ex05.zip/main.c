/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX04
Enunciado: Elabore um algoritmo para obter 10 valores do usuário e exibir a quantidade de valores negativos
(menores que zero) que foram informados.
Casos de teste:
a) Para os valores 1, -1, 10, 21, -14, 30, -1, 8, -9 e -20, a quantidade de valores negativos é 5;
b) Para os valores -1, 0, -10, 5, 20, 3, -8, 44, 2 e 11, a quantidade de valores negativos é 3;
c) Para os valores -5, -1, 10, -13, -8, 3, -90, 8, -9 e -21, a quantidade de valores negativos é 7
#include <stdio.h>
*/
#include <stdio.h>
int main(){
	
	//Declaração de variaveis
	int num=0, aux=0, i=0, cont=1;
	//Entrada de dados
	//Processamento
	while (i<=10){
	    printf("Insira o %d valor: \n", cont);
        scanf("%d", &num);
        cont++;
	    if (num<0){
	        aux++;
	    } 
	    i++;
	}
	printf("A quantidade de numeros ímpares é: %d", aux);
}





