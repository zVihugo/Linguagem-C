#include <stdio.h>

//Cabeçalho da função main
int main(){
    
    //Declaraçõa de variaveis 
    float aux,
          numerador = 1, 
          denominador;
    
    //Processamento
    for (denominador = 1; denominador <=50; denominador++){
        aux = aux + (numerador / denominador);
        
        numerador = numerador + 2;
    }
    printf("%.1f", aux);
    
    
 
 
 
       
}