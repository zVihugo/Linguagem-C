/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT04_EX07
Enunciado: Elabore um algoritmo para calcular a média das notas de uma prova realizada pelos alunos de uma turma.
O número de alunos existentes na turma deve ser informado pelo usuário.
Casos de teste:
a) Para uma turma de 6 alunos e notas 7,5, 5,0, 7,5, 6,0, 7,0, 6,0, 6,0, a média é 6,5;
b) Para uma turma de 5 alunos e notas 9,0, 9,5, 5,5, 8,5, 8,0, a média é 8,1;
c) Para uma turma de 10 alunos e notas 9,0, 9,5, 9,0, 8,0, 6,0, 7,0, 7,5, 9,0, 9,0, 6,0, a média é 8,0. 
*/
#include <stdio.h>

int main(){
    //Declaração de variaveis
    int contador=1, aux, i=1;
    float soma=0, media=0, valor;
    //Entrada de dados
    printf("Bom dia, digite quantos alunos tem na sala \n");
    scanf("%d", &aux);
    //Processamento
    while(contador<=aux){
        printf("Digite a %d nota: ", i);
        scanf("%f", &valor);
        soma += valor; //Comando que soma as notas sucessivamente
        contador++;
        i++;
    }
    media = soma/aux; //Realiza o cálculo da media, com a quantidade de alunos fornecidos
    printf("A soma da sala com %d, é: %.2f ", aux, media); //Saída de dados
    return 0;
}


