/*
Dado o conjunto da temperatura média de cada um dos dias do mês (para um mês de trinta dias), faça
um algoritmo para calcular:
? A menor temperatura do mês;
? A maior temperatura do mês;
? A temperatura média mensal;
? O número de dias no mês em que a temperatura foi inferior à média mensal.
*/

#include <stdio.h>
#include <locale.h>
#define N 30

int main()
{
	setlocale(LC_ALL, "Portuguese");
	
	float temperatura[N], menortemp = 0, maiortemp = 0, mediatemp; 
	
	int i, aux = 0, cont = 0; 
	
	for(i=0; i<N; i++)
	{
		printf("Digite a temperatura do dia %d: ", i+1); 
		scanf("%f", &temperatura[i]); 
		
		if(aux == 0)
		{
			menortemp = temperatura[i];
			aux++; 
		}
		
		if (temperatura[i] > maiortemp)
		{
			maiortemp = temperatura[i];
		}
		
		if (temperatura[i] < menortemp)
		{
			menortemp = temperatura[i]; 
		}
		
		mediatemp += temperatura[i]; 
	} 
	
	mediatemp = mediatemp / 30; 
	
	for(i=0; i<N; i++)
	{
		if (temperatura[i] < mediatemp)
		{
			cont++;
		}
	}
	
	printf("%.1f foi a menor temperatura do mes\n", menortemp); 
	printf("%.1f foi a maior temperatura do mes\n", maiortemp);
	printf("%.1f foi a media de temperatura do mes\n", mediatemp); 
	printf("A temperatura foi inferior a media mensal em %d\n", cont);
	
	return 0;
}