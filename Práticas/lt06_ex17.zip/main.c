/*Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:03/10/2022
EX: LT05_EX16
Enunciado: Faça um algoritmo para calcular o resultado de uma divisão representada por uma fração. Solicitar o
numerador e o denominador para o usuário e, se o denominador for igual a zero, mostrar a mensagem
“Erro: divisão por zero” e solicitar novamente o denominador. A divisão somente será realizada quando o
usuário entrar com um denominador diferente de zero.
Casos de teste:
a) Para numerador igual a 16 e denominador igual a 2, o resultado é 8;
b) Para numerador igual a 5 e denominador igual a 0, será apresentada a mensagem “Erro: divisão por
zero” e será solicitado novamente o denominador;
c) Para numerador igual a 5 e denominador igual a 2, o resultado é 2.5. 

*/

#include <stdio.h>
#include <locale.h>

//Cabeçalho da função main

int main()
{
	
	setlocale(LC_ALL, "Portuguese");
	
	//Declaração de variaveis
	int fatorial,
		resposta = 1,
		n = 0;
	
	puts("Bom dia\n");
	
	printf("Digite o valor do número, para saber qual é o seu fatorial: \n");	
	scanf("%d", &fatorial);
		
	n = fatorial; //Auxiliar para guardar o valor de fatorial, e aprensentar na saída de dados
	
	//Processamento
	for ( ; fatorial >= 1; --fatorial) //-- é decremento, para ir diminuindo o valor de fatorial
	{
		resposta *= fatorial; //A variavel resposta, serve como variavel auxiliar, para armazenar os valores de decremento
		
	}
	
	//Saída de dados
	
	printf("%d! é %d", n, resposta);
	
	//printf("A resposta é: %d", resposta); 
    
	return 0;
}
