/******************************************************************************
Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:07/09/2022
EX: LT02_EX03
Enunciado: Dados três valores (A, B e C), faça um algoritmo para verificar se podem ser os comprimentos dos lados
de um triângulo; exibir a mensagem “É um triângulo” ou a mensagem “Não é um triângulo”. Utilize a
seguinte propriedade: o comprimento de cada lado de um triângulo é menor do que a soma dos
comprimentos dos outros dois lados.
Casos de teste:
a) Para os valores 5, 7 e 10, será apresentada a mensagem “É um triângulo”;
b) Para os valores 20, 10 e 5, será apresentada a mensagem “Não é um triângulo”

*******************************************************************************/

#include <stdio.h>

int main (){
    
    int A, B, C;
    
    //Entrada de dados
    
    printf("Digite o valor de A: \n");
    scanf("%d", &A);
    
    printf("Digite o valor de B: \n");
    scanf("%d", &B);
    
    printf("Digite o valor de C: \n");
    scanf("%d", &C);
    
    //Processamento
    
    if ( (A+B>C) && (A+C>B) && (B+C>A)){
        printf("Forma um triângulo.");
    }
    else {
        printf("Não forma um triângulo.");
    }
}