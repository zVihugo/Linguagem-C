/*
/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:25/09/2022
EX: LT03_EX04
Enunciado: Faça um algoritmo para mostrar um menu com as opções de um cardápio de restaurante ao usuário e
obter o prato desejado. Após a escolha do prato, perguntar ao usuário se deseja pagar a gorjeta do garçom
de 10% sobre o valor do prato e mostrar o valor final de acordo com a resposta.
Código Prato Valor
1 Picanha 25,00
2 Lasanha 20,00
3 Strogonoff 18,00
4 Bife acebolado 15,00
5 Pão com ovo 5,00
Casos de teste:
a) Para opção com código igual a 2 e com pagamento de gorjeta do garçom, o valor final é R$ 22,00;
b) Para opção com código igual a 4 e sem pagamento de gorjeta do garçom, o valor final é R$ 15,00
*/

#include <stdio.h>
#include <locale.h>

int main (){
	
	int cod, gorj;
	float aux;
	
	
	
	
	setlocale(LC_ALL, "Portuguese");
	
	puts("Bem vindo ao nosso restaurante, segue abaixo o nosso cardápio: ");
    printf("Código      Prato                   Valor \n");
    printf("1           Picanha                 25,00\n");
    printf("2           Lasanha                 20,00\n");
    printf("3           Strogonoff              18,00\n");
    printf("4           Bife acebolado          15,00\n");
    printf("5           Pão com ovo             5,00\n");	
    
printf("Digite o valor do código desejado: \n");
scanf("%d", &cod);
    
printf("Caso queira pagar gorjeta digite 1, se não digite 2: \n");
scanf("%d", &gorj);

switch(cod){
	case 1:
	    aux = 25.00;
	break;
	case 2: 
	    aux = 20.00;
	break;
	case 3:
	    aux = 18.00;
	break;
	case 4: 
	    aux = 15.00;
	break;
	case 5:
	    aux = 5.00;
	break;
	default:
	    printf("Guatemala digita certo");
	break;
}  
    if (gorj == 1){
        printf("O valor final é: %.2f", aux+(aux*0.1));
    }
    else if(gorj ==2){
        printf("O valor final é: %.2f", aux);
    }
    else{
        printf("ERRADO AMIGÃO");
    }

}
