/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:23/09/2022
EX: LT02_EX11
Enunciado: Faça um algoritmo para calcular o desconto do Imposto de Renda (IR) de um funcionário, solicitar o salário
bruto e exibir na saída o salário líquido e o desconto. A alíquota do IR a ser utilizada no cálculo do desconto
depende do salário bruto e é determinada de acordo com a seguinte tabela:
Salário Bruto Alíquota
Até R$ 1.900,00 Isento
De R$ 1.900,01 até R$ 3.000,00 7,5%
De R$ 3.000,01 até R$ 4.000,00 15%
De R$ 4.000,01 até R$ 4.700,00 22,5%
Acima de 4.700,00 27,5
Casos de teste:
a) Para o funcionário com salário bruto de R$ 1.100,00, o salário líquido é de R$ 1.100,00 e o desconto é
de R$ 0,00;
b) Para o funcionário com salário bruto de R$ 2.200,00, o salário líquido é de R$ 2.035,00 e o desconto é
de R$ 165,00;
c) Para o funcionário com salário bruto de R$ 3.300,00, o salário líquido é de R$ 2.805,00 e o desconto é
de R$ 495,00;
d) Para o funcionário com salário bruto de R$ 4.500,00, o salário líquido é de R$ 3847,50 e o desconto é
de R$ 1.012,50;
e) Para o funcionário com salário bruto de R$ 8.000,00, o salário líquido é de R$ 5.800,00 e o desconto é
de R$ 2.200,00; 


*******************************************************************************/
#include <stdio.h>


int main()
{
    float salbruto, desconto, saliq; //Declaração de variáveis
    
    printf("Bom dia!, vamos calcular o imposto de renda?\n"); //Entrada de dados
    printf("Segue a tabela de para o cálculo: \n");
    printf("Salário Bruto                   Alíquota\n");
    printf("Até R$ 1.900,00                 Isento\n");
    printf("De R$ 1.900,01 até R$ 3.000,00  7,5\n");
    printf("De R$ 3.000,01 até R$ 4.000,00  15\n");
    printf("e R$ 4.000,01 até R$ 4.700,00   22,5\n");
    printf("Acima de 4.700,00               27,5\n");
    
    printf("Digite o seu salário Bruto: \n");
    scanf("%f", &salbruto);
    
    //Processamento
    
    if ( salbruto <= 1900){
        
        saliq = salbruto;
        
        printf("Para o funcionário com salário bruto de R$ %.2f, o salário líquido é de R$ %.2f e o desconto é de R$ 0,00;", salbruto, saliq);
    }
    if ( 1900 < salbruto && salbruto <= 3000){
        
        desconto = salbruto * 0.075;
        saliq =  salbruto - desconto;
        printf("Para o funcionário com salário bruto de R$ %.2f, o salário líquido é de R$ %.2f e o desconto é de R$ %.2f;", salbruto, saliq, desconto);
    }
    if ( 3000 < salbruto && salbruto<= 4000 ){
        
        desconto = salbruto * 0.15;
        saliq = salbruto - desconto;
        
        printf("Para o funcionário com salário bruto de R$ %.2f, o salário líquido é de R$ %.2f e o desconto é de R$ %.2f;", salbruto, saliq, desconto);
    }
    if ( 4000 < salbruto && salbruto <= 4700){
        
        desconto = salbruto * 0.225;
        saliq = salbruto - desconto;
        
        printf("Para o funcionário com salário bruto de R$ %.2f, o salário líquido é de R$ %.2f e o desconto é de R$ %.2f;", salbruto, saliq, desconto);
    }
    else  {
        
        desconto = salbruto * 0.275;
        saliq = salbruto - desconto;
        
        printf("Para o funcionário com salário bruto de R$ %.2f, o salário líquido é de R$ %.2f e o desconto é de R$ %.2f;", salbruto, saliq, desconto);
    }
    
    return 0;
}






















