/*****************************************************************************
Enunciado: Faça um algoritmo para obter um valor qualquer e depois perguntar ao usuário se este valor está em dólares ou em reais e fazer o seguinte: (a) caso a escolha do usuário for dólares, converter o valor para reais; (b) caso a escolha do usuário for reais, converter o valor para dólares. O algoritmo deve solicitar ao usuário a cotação atual do dólar antes de realizar a conversão.Casos de teste:
a) Para o valor de 100 em dólares, com a cotação do dólar em 5,20 reais, o valor em reais é 520 reais;
b) Para o valor de 100 em reais, com a cotação do dólar em 5,20 reais, o valor em dólar é 19,23 dólares. 

*******************************************************************************/
#include <stdio.h> //Importa a biblioteca de entrada e saída

//Cabeçalho da função main

int main() 
{
    //Declaração de variáveis
    float vqualquer, cotacao, conversao; 
    int escolha; 
    
    //Entrada de dados
    
    printf("Digite um valor qualquer: \n");
    scanf("%f", &vqualquer);
    
    printf("Caso o valor esteja em dólar digite 1, caso esteja em Reais digite 2: \n"); //Pede para o usuário escolher a moeda
    scanf("%d", &escolha);
    
    printf("Digite o valor da cotação atual: \n");
    scanf("%f", &cotacao);
    
    //Processamento
    
    if (escolha == 1) //SE a escolha for dólar, realizar o processamento abaixo
    {
        
        conversao = vqualquer * cotacao; //Converte para real - dólar
        
        printf("Para o valor de %.1f em dólares, com a cotação do dólar em %.2f, o valor em reais é R$ %.2f reais.", vqualquer, cotacao, conversao); //Saída de dados
        
    }

    else  //SE NAO, realizar o processamento abaixo
    {
     
        conversao = vqualquer / cotacao; //Converte dólar - Real 
        
        printf("Para o valor de %.1f em reais, com a cotação do dólar em %.2f, o valor em dólar é U$ %.2f dólares", vqualquer, cotacao, conversao); //Saída de dados
    }
    return 0;
}


