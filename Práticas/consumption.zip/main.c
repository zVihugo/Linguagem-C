/*
Nome......: Victor Hugo F. Moreira
Data......: 20/09/2022
Turma.....: AS31A - N11A
ra........: 2503581
*/

#include<stdio.h>
int main ()
{
    int X;
    
    float Y, consumo;
    
    scanf("%d", &X);
    
    scanf("%f", &Y);
    
    consumo = X / Y;
    
    printf("%.3f Km/l\n", consumo);
    
    return 0;
}
