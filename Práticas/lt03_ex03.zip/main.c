/******************************************************************************

Nome: Victor Hugo Favaro Moreira
Turma: AS31A-N11
data:25/09/2022
EX: LT03_EX03
Enunciado: Faça um algoritmo para obter o salário e o código do cargo de um funcionário e depois calcular o aumento
e o novo salário de acordo com a tabela. Se o cargo não estiver na tabela, o aumento será de 40%. No
final, mostrar o cargo, o salário antigo, o novo salário e o aumento.
Código Cargo Percentual
101 Supervisor 10%
102 Engenheiro 20%
103 Técnico 30%
Casos de teste:
a) Para o salário de R$ 5.000,00 e código igual a “101”, será apresentado o cargo de “Supervisor”, o salário
antigo de R$ 5.000,00, o novo salário de R$ 5.500,00 e o aumento de R$ 500,00;
b) Para o salário de R$ 10.550,00 e código igual a “102”, será apresentado o cargo de “Engenheiro”, o
salário antigo de R$ 10.550,00, o novo salário de R$ 12.660,00 e o aumento de R$ 2.110,00;
c) Para o salário de R$ 5.000,00 e código igual a “103”, será apresentado o cargo de “Técnico”, o salário
antigo de R$ 5.000,00, o novo salário de R$ 6.500,00 e o aumento de R$ 1.500,00;
d) Para o salário de R$ 5.000,00 e código igual a “110”, será apresentado o cargo de “Cargo não consta na
tabela”, o salário antigo de R$ 1.000,00, o novo salário de R$ 1.400,00 e o aumento de R$ 400,00. 

*******************************************************************************/
#include <stdio.h>

//Cabeçalho da função main
int main()
{
    float sal, novsal; //Declaração de variaveis 
    int cod;
    //Entrada de dados
    
    printf("Digite o valor do seu atual salário: \n");
    scanf("%f", &sal);
    
    printf("Digite o código do seu cargo: \n");
    scanf("%d", &cod);
    
    //Processamento 
     
    switch (cod){
     
        case 102: //Se o código inserido for 101, ele realiza este processamento descrito abaixo
        novsal = sal + (sal*0.2);
        printf("Cargo Engenheiro, salário antigo de R$ %.2f, novo salário de R$ %.2f com aumento de R$ %.2f", sal, novsal, (sal*0.2));
        break;
        
    
        case 101: //Se o código inserido for 102, ele realiza este processamento descrito abaixo
        novsal = sal + (sal*0.2);
        printf("Cargo Supervisor, salário antigo de R$ %.2f, novo salário de R$ %.2f com aumento de R$ %.2f", sal, novsal, (sal*0.1));
        break;
        
    
        case 103:  //Se o código inserido for 103, ele realiza este processamento descrito abaixo
        novsal = sal + (sal*0.3);
        printf("Cargo Técnico, salário antigo de R$ %.2f, novo salário de R$ %.2f com aumento de R$ %.2f", sal, novsal, (sal*0.3));
        break;
        
    
        default:
        novsal = sal + (sal*0.4); //Se o código inserido não constar na tabela, ele realiza este processamento descrito abaixo
        printf("''Código do cargo não consta no sistema'', salário antigo de R$ %.2f, novo salário de R$ %.2f com aumento de R$ %.2f", sal, novsal, (sal*0.4));
        break;
       
     }

    return 0;
}


