// Nome: Victor Hugo Favaro Moreira
// Turma: AS31A-N11
// data:07/09/2022
// Enunciado: LT01_EX05

#include <stdio.h>
#include <math.h>
#include <locale.h>

int main ()
{
	setlocale(LC_ALL, "Portuguese"); //Accent in devc++ IDE
	
	//Variable Declaration
	
	float pmontadora, pvenda, icms, ipi, lucro;
	
	//Data Input
	
	printf("Digite o valor da montadora: ");
	scanf("%f", &pmontadora);
	
	//Processing
	
	icms = pmontadora * 0.17; //Calculate the taxes
	ipi = pmontadora * 0.11; //Calculate the taxes
	lucro = pmontadora * 0.15; //Calculate profit
	pvenda = pmontadora + icms + ipi + lucro; //Calculate the selling price
	
	//Data output
	
	printf("O valor de venda do carro é: R$%10.2f\n", pvenda);
	printf("O valor do IPI.............: R$%10.2f\n", ipi);
	printf("O valor do ICMS............: R$%10.2f\n", icms);
	printf("O lucro foi de.............: R$%10.2f\n", lucro);
	
	return 0;
}